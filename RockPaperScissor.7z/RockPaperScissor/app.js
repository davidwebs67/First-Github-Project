let playerScore = 0;
let computerScore = 0;

let input = (confirm("Are you ready to play 5 games of Rock paper Scissor with me?"))
if (input === true) {
     game();
} else if (input === false) {
    alert("Alright then, good bye!")
}
// create a function called getComputerChoice 
// that will return either rock paper or scissor randomly.

function getComputerChoice() {
    // creates an variable of an array with the strings of rock, paper scissor
    const computerArray = ["rock", "paper", "scissor"]
    // this new variable will print print out randomly a number length of the array
    let ComputerChoice = Math.floor(Math.random() * computerArray.length);
    // if the number is 0, 1 or 2 then return the statement
    if(ComputerChoice === 0) {
        return "rock";
    } else if (ComputerChoice === 1) {
        return "paper";
    } else if (ComputerChoice === 2) {
        return "scissor"
    }
}

// this function takes two parameter and compare them as a usual rock paper scissor game


function playRound(playerSelection, computerSelection) {
    if(playerSelection === computerSelection) {
        console.log(`The round is a draw!`)
        console.log(`Player score: ${playerScore} & Computer score: ${computerScore}`)
        if(playerScore === computerScore) {
            console.log("Game is a draw! wanna play again?")
        }

    } else if((playerSelection === "rock" && computerSelection === "paper") || 
              (playerSelection === "paper" && computerSelection === "scissor") || 
              (playerSelection === "scissor" && computerSelection === "rock")) 
        {
        console.log(`You lost: ${computerSelection} beats ${playerSelection}`)
        console.log(`Player points:${playerScore} & Computer points: ${++computerScore}`) 
        } else if ((playerSelection === "rock" && computerSelection === "scissor") || 
               (playerSelection === "paper" && computerSelection === "rock") || 
               (playerSelection === "scissor" && computerSelection === "paper")) 
        {
        console.log(`You won: ${playerSelection} beats ${computerSelection}`)
        console.log(`Player points:${++playerScore} & Computer points: ${computerScore}`)
    } 
}

function game() {
    for (let i = 1; i <= 5; i++) {  
        // then we create a new variable and assign it to a prompt to get the user input
        const playerSelection = prompt(`Choose between Rock Paper Scissor! Good luck!`);
        // assign a variable to the get a random answer, rock paper or scissor 
        const computerSelection = getComputerChoice();
        // checks in the console if computerSelection is the random output(rock paper or scissor)
        console.log(`ComputerSelection is: ${computerSelection}`)
        // checks in the console if playerSelection is a random string of (rock paper or scissor)
        console.log(`PlayerSelection is: ${playerSelection}`)
        console.log(playRound(playerSelection, computerSelection))  
    } 
}



