const body = document.body
const heading =  document.querySelector(".title-heading")
const container = document.querySelector(".container")
const buttons = document.querySelectorAll("button");
const ComputerScoring = document.querySelector(".computer")
const playerScoring = document.querySelector(".player")
const Scoreboard = document.querySelector(".Scoreboard")
const comments = document.querySelector(".comments");
const PlayAgain = document.createElement("div")
PlayAgain.setAttribute("id", "general")
const text = document.createElement("p")
const buttonAfter = document.createElement("button")


let playerScore = 0;
let computerScore = 0;


// create a function called getComputerChoice 
// that will return either rock paper or scissor randomly.

buttons.forEach((button) => {
    button.addEventListener("click", playRound)
})

function getComputerChoice() {
    // creates an variable of an array with the strings of rock, paper scissor
    const computerArray = ["rock", "paper", "scissor"]
    // this new variable will print print out randomly a number length of the array
    let ComputerChoice = Math.floor(Math.random() * computerArray.length);
    // if the number is 0, 1 or 2 then return the statement
    if(ComputerChoice === 0) {
        return "rock";
    } else if (ComputerChoice === 1) {
        return "paper";
    } else if (ComputerChoice === 2) {
        return "scissor"
    }
}

function playRound(e) {
    const computerSelection = getComputerChoice();
    const playerSelection = e.target.id

    if(playerSelection === computerSelection) {
        comments.textContent = `The round is a draw!`
    } else if ((playerSelection === "rock" && computerSelection === "scissor") || 
               (playerSelection === "paper" && computerSelection === "rock") || 
               (playerSelection === "scissor" && computerSelection === "paper")) 
        {
        comments.textContent = `You won: ${playerSelection} beats ${computerSelection}`
        playerScoring.innerHTML = `<p>PlayerScore:<span>${++playerScore}</span></p>`
    } else if((playerSelection=== "rock" && computerSelection === "paper") || 
    (playerSelection === "paper" && computerSelection === "scissor") || 
    (playerSelection === "scissor" && computerSelection === "rock")) {
    comments.textContent = `You lost: ${computerSelection} beats ${playerSelection}`
    ComputerScoring.innerHTML = `<p>ComputerScore:<span>${++computerScore}</span></p>`
   
}
if (playerScore === 5) {
    body.removeChild(container)
    body.appendChild(PlayAgain)
    PlayAgain.appendChild(text)
    PlayAgain.appendChild(buttonAfter)
    PlayAgain.classList.add("dark")
    buttonAfter.classList.add("btn-after")
    text.classList.add("animated")
    text.textContent = "You've successfully defeated the Computer! Good Work"
    buttonAfter.textContent = "Play Again?"
} else if (computerScore === 5) {
    body.removeChild(container)
    PlayAgain.classList.add("dark")
    text.classList.add("animated")
    text.textContent = "Aww next time you will get him for sure"
}
}



